kubectl logs job-lenet-cpu-16-12-16384-16-0> lenet-cpu-16-12-16384-16-0.log & 
kubectl logs job-lenet-gpu-16-12-16384-16-0> lenet-gpu-16-12-16384-16-0.log & 
kubectl logs job-lenet-cpu-16-12-16384-16-1> lenet-cpu-16-12-16384-16-1.log & 
kubectl logs job-lenet-gpu-16-12-16384-16-1> lenet-gpu-16-12-16384-16-1.log & 
kubectl logs job-lenet-cpu-16-12-16384-16-2> lenet-cpu-16-12-16384-16-2.log & 
kubectl logs job-lenet-gpu-16-12-16384-16-2> lenet-gpu-16-12-16384-16-2.log & 
